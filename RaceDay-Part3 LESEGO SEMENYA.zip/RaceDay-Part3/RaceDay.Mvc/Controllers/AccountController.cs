using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class AccountController(RaceDayApiClient api):Controller {
 [HttpGet,AllowAnonymous]public IActionResult Register()=>View(new RegisterForm());
 [HttpPost,AllowAnonymous,ValidateAntiForgeryToken]public async Task<IActionResult> Register(RegisterForm form){
  if(form.Role is not ("Organiser" or "Participant"))ModelState.AddModelError(nameof(form.Role),"Choose a valid role.");
  if(!ModelState.IsValid)return View(form);
  var result=await api.Send<UserInfo>(HttpMethod.Post,"api/auth/register",new{form.Name,form.Email,form.Password,form.Role});
  if(!result.Ok){ModelState.AddModelError("",result.Error);return View(form);}
  TempData["Success"]="Registration complete. Sign in to RaceDay.";return RedirectToAction(nameof(Login));
 }
 [HttpGet,AllowAnonymous]public IActionResult Login(string? returnUrl=null)=>View(new LoginForm());
 [HttpPost,AllowAnonymous,ValidateAntiForgeryToken]public async Task<IActionResult> Login(LoginForm form,string? returnUrl=null){
  if(!ModelState.IsValid)return View(form);
  var result=await api.Login(form);
  if(!result.Ok||result.Data is null){ModelState.AddModelError("",result.Error);return View(form);}
  var user=result.Data.User;
  HttpContext.Session.Clear();HttpContext.Session.SetString("ApiCookie",result.Data.ApiCookie);
  HttpContext.Session.SetString("Role",user.Role);HttpContext.Session.SetString("Name",user.Name);
  var claims=new[]{new Claim(ClaimTypes.NameIdentifier,user.Id.ToString()),new Claim(ClaimTypes.Name,user.Name),new Claim(ClaimTypes.Role,user.Role)};
  await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme)));
  if(!string.IsNullOrWhiteSpace(returnUrl)&&Url.IsLocalUrl(returnUrl))return LocalRedirect(returnUrl);
  return RedirectToAction("Index",user.Role=="Organiser"?"Organiser":"Participant");
 }
 [HttpPost,Authorize,ValidateAntiForgeryToken]public async Task<IActionResult> Logout(){
  await api.Send<bool>(HttpMethod.Post,"api/auth/logout");HttpContext.Session.Clear();await HttpContext.SignOutAsync();
  TempData["Success"]="You have been signed out.";return RedirectToAction("Index","Home");
 }
 [HttpGet,Authorize]public async Task<IActionResult> Profile(){
  var profile=await api.Get<UserInfo>("api/profile");if(!profile.Ok){TempData["Error"]=profile.Error;return RedirectToAction("Index","Home");}
  return View(profile.Data);
 }
 [HttpPost,Authorize,ValidateAntiForgeryToken]public async Task<IActionResult> Profile(string name){
  if(string.IsNullOrWhiteSpace(name)){TempData["Error"]="Name cannot be empty.";return RedirectToAction(nameof(Profile));}
  var result=await api.Send<UserInfo>(HttpMethod.Put,"api/profile",new{Name=name});
  TempData[result.Ok?"Success":"Error"]=result.Ok?"Profile updated.":result.Error;
  return RedirectToAction(nameof(Profile));
 }
 [HttpPost,Authorize,ValidateAntiForgeryToken]public async Task<IActionResult> Photo(IFormFile? photo){
  if(photo is null||photo.Length>5*1024*1024){TempData["Error"]="Select an image smaller than 5 MB.";return RedirectToAction(nameof(Profile));}
  var result=await api.Upload("api/profile/photo",photo);TempData[result.Ok?"Success":"Error"]=result.Ok?"Profile photo uploaded.":result.Error;
  return RedirectToAction(nameof(Profile));
 }
 [HttpGet]public IActionResult Denied()=>View();
}
