using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class HomeController(RaceDayApiClient api):Controller {
 public async Task<IActionResult> Index(string? q,string? type){
  var result=await api.Get<List<RaceEvent>>("api/events");
  if(!result.Ok){ViewBag.Error=result.Error;return View(new List<RaceEvent>());}
  var events=(result.Data??new()).Where(e=>e.Date>=DateTime.Today);
  if(!string.IsNullOrWhiteSpace(q))events=events.Where(e=>e.Name.Contains(q,StringComparison.OrdinalIgnoreCase)||e.Location.Contains(q,StringComparison.OrdinalIgnoreCase));
  if(!string.IsNullOrWhiteSpace(type))events=events.Where(e=>e.EventType==type);
  ViewBag.Query=q;ViewBag.Type=type;
  return View(events.OrderBy(e=>e.Date).ToList());
 }
 public async Task<IActionResult> Details(int id){
  var ev=await api.Get<RaceEvent>($"api/events/{id}");if(!ev.Ok||ev.Data is null)return NotFound();
  var cats=await api.Get<List<RaceCategory>>($"api/events/{id}/categories");
  return View(new EventDetailsPage{Event=ev.Data,Categories=cats.Data??new()});
 }
 public IActionResult Error()=>View();
}
