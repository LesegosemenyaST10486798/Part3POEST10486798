using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[Authorize(Roles="Organiser")]
public class OrganiserController(RaceDayApiClient api):Controller {
 public async Task<IActionResult> Index(){
  var res=await api.Get<List<RaceEvent>>("api/events/mine");
  if(!res.Ok){TempData["Error"]=res.Error;return View(new OrganiserDashboard());}
  var page=new OrganiserDashboard{Events=res.Data??new()};
  foreach(var ev in page.Events){var enrols=await api.Get<List<Enrolment>>($"api/enrolments/event/{ev.Id}");page.EnrolmentCounts[ev.Id]=enrols.Data?.Count??0;}
  return View(page);
 }
 public IActionResult Create()=>View("EventForm",new EventForm());
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Create(EventForm form){
  if(form.EventType is not ("Run" or "Walk" or "Cycle"))ModelState.AddModelError(nameof(form.EventType),"Choose a valid event type.");
  if(form.Date<DateTime.Today)ModelState.AddModelError(nameof(form.Date),"Select a future event date.");
  if(!ModelState.IsValid)return View("EventForm",form);
  var result=await api.Send<RaceEvent>(HttpMethod.Post,"api/events",new{form.Name,form.Description,form.Date,form.Location,form.DistanceKm,form.EventType});
  if(!result.Ok||result.Data is null){ModelState.AddModelError("",result.Error);return View("EventForm",form);}
  if(form.Banner is not null){var upload=await api.Upload($"api/events/{result.Data.Id}/banner",form.Banner);if(!upload.Ok)TempData["Error"]="Event created but banner could not be uploaded: "+upload.Error;}
  TempData["Success"]="Event created successfully.";return RedirectToAction(nameof(Manage),new{id=result.Data.Id});
 }
 public async Task<IActionResult> Edit(int id){
  var ev=await api.Get<RaceEvent>($"api/events/{id}");if(!ev.Ok||ev.Data is null)return NotFound();
  var owned=await IsOwner(id);if(!owned)return Forbid();
  var x=ev.Data;return View("EventForm",new EventForm{Id=id,Name=x.Name,Description=x.Description,Date=x.Date,Location=x.Location,DistanceKm=x.DistanceKm,EventType=x.EventType});
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Edit(EventForm form){
  if(form.EventType is not ("Run" or "Walk" or "Cycle"))ModelState.AddModelError(nameof(form.EventType),"Choose a valid event type.");
  if(!ModelState.IsValid)return View("EventForm",form);
  var result=await api.Send<RaceEvent>(HttpMethod.Put,$"api/events/{form.Id}",new{form.Name,form.Description,form.Date,form.Location,form.DistanceKm,form.EventType});
  if(!result.Ok){ModelState.AddModelError("",result.Error);return View("EventForm",form);}
  if(form.Banner is not null){var upload=await api.Upload($"api/events/{form.Id}/banner",form.Banner);if(!upload.Ok)TempData["Error"]=upload.Error;}
  TempData["Success"]="Event updated.";return RedirectToAction(nameof(Manage),new{id=form.Id});
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Delete(int id){
  var result=await api.Send<bool>(HttpMethod.Delete,$"api/events/{id}");TempData[result.Ok?"Success":"Error"]=result.Ok?"Event deleted.":result.Error;
  return RedirectToAction(nameof(Index));
 }
 public async Task<IActionResult> Manage(int id){
  var ev=await api.Get<RaceEvent>($"api/events/{id}");if(!ev.Ok||ev.Data is null)return NotFound();
  if(!await IsOwner(id))return Forbid();
  var enr=await api.Get<List<Enrolment>>($"api/enrolments/event/{id}");
  var res=await api.Get<List<RaceResult>>($"api/results/event/{id}");
  return View(new OrganiserEventPage{Event=ev.Data,Enrolments=enr.Data??new(),Results=res.Data??new()});
 }
 public async Task<IActionResult> Categories(int id){
  if(!await IsOwner(id))return Forbid();
  var res=await api.Get<List<RaceCategory>>($"api/events/{id}/categories");ViewBag.EventId=id;return View(res.Data??new());
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> AddCategory(CategoryForm form){
  if(!ModelState.IsValid){TempData["Error"]="Enter a category name.";return RedirectToAction(nameof(Categories),new{id=form.EventId});}
  var result=await api.Send<RaceCategory>(HttpMethod.Post,$"api/events/{form.EventId}/categories",new{form.Name});
  TempData[result.Ok?"Success":"Error"]=result.Ok?"Category added.":result.Error;
  return RedirectToAction(nameof(Categories),new{id=form.EventId});
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> EditCategory(CategoryForm form){
  if(!ModelState.IsValid){TempData["Error"]="Enter a category name.";return RedirectToAction(nameof(Categories),new{id=form.EventId});}
  var result=await api.Send<RaceCategory>(HttpMethod.Put,$"api/events/{form.EventId}/categories/{form.CategoryId}",new{form.Name});
  TempData[result.Ok?"Success":"Error"]=result.Ok?"Category updated.":result.Error;
  return RedirectToAction(nameof(Categories),new{id=form.EventId});
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> DeleteCategory(int eventId,int categoryId){
  var result=await api.Send<bool>(HttpMethod.Delete,$"api/events/{eventId}/categories/{categoryId}");
  TempData[result.Ok?"Success":"Error"]=result.Ok?"Category deleted.":result.Error;
  return RedirectToAction(nameof(Categories),new{id=eventId});
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> RecordResult(ResultForm form){
  if(!ModelState.IsValid||!TimeSpan.TryParseExact(form.FinishTime,@"hh\:mm\:ss",null,out var time)){
   TempData["Error"]="Enter valid finish time as HH:MM:SS and position.";return RedirectToAction(nameof(Manage),new{id=form.EventId});
  }
  var result=await api.Send<RaceResult>(HttpMethod.Post,"api/results",new{form.EnrolmentId,FinishTime=time,form.Position});
  TempData[result.Ok?"Success":"Error"]=result.Ok?"Race result saved.":result.Error;
  return RedirectToAction(nameof(Manage),new{id=form.EventId});
 }
 private async Task<bool> IsOwner(int eventId){var r=await api.Get<List<RaceEvent>>("api/events/mine");return r.Data?.Any(x=>x.Id==eventId)??false;}
}
