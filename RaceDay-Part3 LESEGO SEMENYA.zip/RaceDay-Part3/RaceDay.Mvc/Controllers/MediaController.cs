using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
public class MediaController(RaceDayApiClient api):Controller {
 [AllowAnonymous]public async Task<IActionResult> EventBanner(int id){var image=await api.Image($"api/events/{id}/banner");return image.Bytes is null?NotFound():File(image.Bytes,image.ContentType??"image/jpeg");}
 [Authorize]public async Task<IActionResult> MyPhoto(){var image=await api.Image("api/profile/photo");return image.Bytes is null?NotFound():File(image.Bytes,image.ContentType??"image/jpeg");}
}
