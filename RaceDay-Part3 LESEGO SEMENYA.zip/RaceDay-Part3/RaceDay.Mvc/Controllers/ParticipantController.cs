using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;
using RaceDay.Mvc.Services;
namespace RaceDay.Mvc.Controllers;
[Authorize(Roles="Participant")]
public class ParticipantController(RaceDayApiClient api):Controller {
 public async Task<IActionResult> Index(){
  var events=await api.Get<List<RaceEvent>>("api/events");var mine=await api.Get<List<Enrolment>>("api/enrolments/mine");
  if(!events.Ok)TempData["Error"]=events.Error;
  return View(new ParticipantDashboard{Events=events.Data?.Where(e=>e.Date>=DateTime.Today).OrderBy(e=>e.Date).Take(6).ToList()??new(),Enrolments=mine.Data??new()});
 }
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Enrol(int eventId,int categoryId){
  if(eventId<1||categoryId<1){TempData["Error"]="Select a category before enrolling.";return RedirectToAction("Details","Home",new{id=eventId});}
  var result=await api.Send<Enrolment>(HttpMethod.Post,"api/enrolments",new{eventId,categoryId});
  TempData[result.Ok?"Success":"Error"]=result.Ok?"You are enrolled! Your status is Confirmed.":result.Error;
  return RedirectToAction(result.Ok?nameof(MyEnrolments):"Details",result.Ok?"Participant":"Home",result.Ok?null:new{id=eventId});
 }
 public async Task<IActionResult> MyEnrolments(){var res=await api.Get<List<Enrolment>>("api/enrolments/mine");if(!res.Ok)TempData["Error"]=res.Error;return View(res.Data??new());}
 public async Task<IActionResult> MyResults(){var res=await api.Get<List<RaceResult>>("api/results/mine");if(!res.Ok)TempData["Error"]=res.Error;return View(res.Data??new());}
}
