using System.ComponentModel.DataAnnotations;
namespace RaceDay.Mvc.Models;
public class RaceEvent {
 public int Id {get;set;} public string Name {get;set;}="";public string Description {get;set;}="";
 public DateTime Date {get;set;}public string Location {get;set;}="";public decimal DistanceKm {get;set;}
 public string EventType {get;set;}="Run";public int OrganiserId {get;set;}public bool HasBanner {get;set;}
}
public class RaceCategory {public int Id {get;set;}public int EventId {get;set;}public string Name {get;set;}="";}
public class Enrolment {
 public int Id {get;set;}public int EventId {get;set;}public int CategoryId {get;set;}public int ParticipantId {get;set;}
 public DateTime RegisteredAt {get;set;}public string Status {get;set;}="Confirmed";
 public string EventName {get;set;}="";public DateTime EventDate {get;set;}public string CategoryName {get;set;}="";
 public string ParticipantName {get;set;}="";public string ParticipantEmail {get;set;}="";
}
public class RaceResult {
 public int Id {get;set;}public int EnrolmentId {get;set;}public int EventId {get;set;}
 public string EventName {get;set;}="";public DateTime EventDate {get;set;}public string CategoryName {get;set;}="";
 public string ParticipantName {get;set;}="";public TimeSpan FinishTime {get;set;}public int Position {get;set;}public int TotalFinishers {get;set;}
}
public class UserInfo {public int Id {get;set;}public string Name {get;set;}="";public string Email {get;set;}="";public string Role {get;set;}="";}
public class RegisterForm {
 [Required,MaxLength(80)]public string Name {get;set;}="";
 [Required,EmailAddress]public string Email {get;set;}="";
 [Required,MinLength(8)]public string Password {get;set;}="";
 [Required,Compare(nameof(Password))]public string ConfirmPassword {get;set;}="";
 [Required]public string Role {get;set;}="Participant";
}
public class LoginForm {[Required,EmailAddress]public string Email {get;set;}="";[Required]public string Password {get;set;}="";}
public class EventForm {
 public int Id {get;set;} [Required,MaxLength(120)]public string Name {get;set;}="";
 [MaxLength(1000)]public string Description {get;set;}="";
 [Required]public DateTime Date {get;set;}=DateTime.Today.AddDays(14).AddHours(7);
 [Required,MaxLength(150)]public string Location {get;set;}="";
 [Range(0.1,1000)]public decimal DistanceKm {get;set;}=5;
 [Required]public string EventType {get;set;}="Run";
 public IFormFile? Banner {get;set;}
}
public class CategoryForm {public int EventId {get;set;}public int CategoryId {get;set;}[Required,MaxLength(100)]public string Name {get;set;}="";}
public class ResultForm {public int EventId {get;set;} [Range(1,int.MaxValue)]public int EnrolmentId {get;set;}[Required,RegularExpression(@"^\d{1,3}:([0-5]\d):([0-5]\d)$",ErrorMessage="Enter time as HH:MM:SS, e.g. 00:25:30")]public string FinishTime {get;set;}="00:30:00";[Range(1,int.MaxValue)]public int Position {get;set;}=1;}
public class EventDetailsPage {public RaceEvent Event {get;set;}=new();public List<RaceCategory> Categories {get;set;}=new();}
public class OrganiserDashboard {public List<RaceEvent> Events {get;set;}=new();public Dictionary<int,int> EnrolmentCounts {get;set;}=new();}
public class ParticipantDashboard {public List<RaceEvent> Events {get;set;}=new();public List<Enrolment> Enrolments {get;set;}=new();}
public class OrganiserEventPage {public RaceEvent Event {get;set;}=new();public List<Enrolment> Enrolments {get;set;}=new();public List<RaceResult> Results {get;set;}=new();}
