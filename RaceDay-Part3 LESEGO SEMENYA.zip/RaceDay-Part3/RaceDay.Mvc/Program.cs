using Microsoft.AspNetCore.Authentication.Cookies;
using RaceDay.Mvc.Services;
var builder=WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews(o=>o.Filters.Add(new Microsoft.AspNetCore.Mvc.AutoValidateAntiforgeryTokenAttribute()));
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(o=>{o.Cookie.Name="RaceDay.Mvc.Session";o.Cookie.HttpOnly=true;o.Cookie.IsEssential=true;o.IdleTimeout=TimeSpan.FromMinutes(45);});
builder.Services.AddHttpContextAccessor();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o=>{
 o.LoginPath="/Account/Login";o.AccessDeniedPath="/Account/Denied";o.Cookie.Name="RaceDay.Mvc.Auth";
 o.Cookie.HttpOnly=true;o.Cookie.SameSite=SameSiteMode.Lax;o.ExpireTimeSpan=TimeSpan.FromMinutes(45);
});
builder.Services.AddAuthorization();
builder.Services.AddHttpClient<RaceDayApiClient>(client=>{
 client.BaseAddress=new Uri(builder.Configuration["Api:BaseUrl"]??"http://localhost:5044/");
 client.Timeout=TimeSpan.FromSeconds(30);
}).ConfigurePrimaryHttpMessageHandler(()=>new HttpClientHandler { UseCookies=false });
var app=builder.Build();
if (!app.Environment.IsDevelopment()){app.UseExceptionHandler("/Home/Error");app.UseHsts();app.UseHttpsRedirection();}
app.UseStaticFiles();app.UseRouting();app.UseSession();app.UseAuthentication();app.UseAuthorization();
app.MapControllerRoute(name:"default",pattern:"{controller=Home}/{action=Index}/{id?}");
app.Run();
public partial class Program {}
