using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using RaceDay.Mvc.Models;
namespace RaceDay.Mvc.Services;
public record ApiResult<T>(bool Ok,T? Data,string Error="");
public record SignInResult(UserInfo User,string ApiCookie);
public class RaceDayApiClient {
 private readonly HttpClient _client;private readonly IHttpContextAccessor _context;
 private static readonly JsonSerializerOptions Json=new(){PropertyNameCaseInsensitive=true,PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
 public RaceDayApiClient(HttpClient client,IHttpContextAccessor context){_client=client;_context=context;}
 private HttpRequestMessage Request(HttpMethod method,string path,HttpContent? body=null){
  var req=new HttpRequestMessage(method,path){Content=body};
  var cookie=_context.HttpContext?.Session.GetString("ApiCookie");
  if(!string.IsNullOrWhiteSpace(cookie))req.Headers.TryAddWithoutValidation("Cookie",cookie);
  return req;
 }
 private static async Task<ApiResult<T>> Parse<T>(HttpResponseMessage response){
  if(!response.IsSuccessStatusCode)return new(false,default, response.StatusCode switch{
    HttpStatusCode.Unauthorized=>"Your login has expired. Please sign in again.",
    HttpStatusCode.Forbidden=>"You are not authorised to perform this action.",
    HttpStatusCode.NotFound=>"That item could not be found.",
    HttpStatusCode.Conflict=>"This action conflicts with an existing record. Please check the details.",
    HttpStatusCode.ServiceUnavailable=>"Cloud storage is not configured or available.",
    _=>"The request could not be completed. Please verify your details and try again."});
  if(typeof(T)==typeof(bool))return new(true,(T)(object)true);
  try {var data=await response.Content.ReadFromJsonAsync<T>(Json);return new(true,data);}
  catch(JsonException){return new(false,default,"The service returned unexpected data.");}
 }
 public async Task<ApiResult<T>> Get<T>(string path){
  try{using var request=Request(HttpMethod.Get,path);using var response=await _client.SendAsync(request);return await Parse<T>(response);}
  catch(HttpRequestException){return new(false,default,"Cannot connect to RaceDay API. Start the API and try again.");}
  catch(TaskCanceledException){return new(false,default,"The API took too long to respond.");}
 }
 public async Task<ApiResult<T>> Send<T>(HttpMethod method,string path,object? payload=null){
  try{using var req=Request(method,path,payload is null?null:JsonContent.Create(payload,options:Json));using var response=await _client.SendAsync(req);return await Parse<T>(response);}
  catch(HttpRequestException){return new(false,default,"Cannot connect to RaceDay API. Start the API and try again.");}
  catch(TaskCanceledException){return new(false,default,"The API took too long to respond.");}
 }
 public async Task<ApiResult<SignInResult>> Login(LoginForm model){
  try{using var response=await _client.PostAsJsonAsync("api/auth/login",new{model.Email,model.Password},Json);
   var user=await Parse<UserInfo>(response);if(!user.Ok||user.Data is null)return new(false,null,user.Error);
   var cookie=response.Headers.TryGetValues("Set-Cookie",out var cookies)
    ?cookies.FirstOrDefault(v=>v.StartsWith("RaceDay.Auth=",StringComparison.OrdinalIgnoreCase))?.Split(';')[0]:null;
   if(string.IsNullOrWhiteSpace(cookie))return new(false,null,"The API did not create a login session.");
   return new(true,new SignInResult(user.Data,cookie));
  }catch(HttpRequestException){return new(false,null,"Cannot connect to RaceDay API.");}
 }
 public async Task<ApiResult<bool>> Upload(string path,IFormFile file){
  try{using var body=new MultipartFormDataContent();await using var stream=file.OpenReadStream();
   using var data=new StreamContent(stream);data.Headers.ContentType=new System.Net.Http.Headers.MediaTypeHeaderValue(file.ContentType);
   body.Add(data,"file",Path.GetFileName(file.FileName));
   using var request=Request(HttpMethod.Post,path,body);request.Headers.Add("X-RaceDay-Mvc","1");
   using var response=await _client.SendAsync(request);return await Parse<bool>(response);
  }catch(HttpRequestException){return new(false,false,"Could not connect to image storage service.");}
 }
 public async Task<(byte[]? Bytes,string? ContentType)> Image(string path){
  try{using var request=Request(HttpMethod.Get,path);using var response=await _client.SendAsync(request);
   if(!response.IsSuccessStatusCode)return(null,null);
   return(await response.Content.ReadAsByteArrayAsync(),response.Content.Headers.ContentType?.MediaType??"image/jpeg");
  }catch(HttpRequestException){return(null,null);}
 }
}
