using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;
namespace RaceDay.Api.Data;
public class RaceDb(DbContextOptions<RaceDb> options):DbContext(options) {
 public DbSet<AppUser> Users=>Set<AppUser>(); public DbSet<RaceEvent> Events=>Set<RaceEvent>(); public DbSet<EventCategory> Categories=>Set<EventCategory>(); public DbSet<Enrolment> Enrolments=>Set<Enrolment>(); public DbSet<RaceResult> Results=>Set<RaceResult>();
 protected override void OnModelCreating(ModelBuilder b){
 b.Entity<AppUser>().HasIndex(x=>x.Email).IsUnique(); b.Entity<RaceEvent>().Property(x=>x.DistanceKm).HasPrecision(8,2);
 b.Entity<RaceEvent>().HasOne(x=>x.Organiser).WithMany(x=>x.OrganisedEvents).HasForeignKey(x=>x.OrganiserId).OnDelete(DeleteBehavior.Restrict);
 b.Entity<Enrolment>().HasOne(x=>x.Participant).WithMany(x=>x.Enrolments).HasForeignKey(x=>x.ParticipantId).OnDelete(DeleteBehavior.Restrict);
 b.Entity<Enrolment>().HasOne(x=>x.Event).WithMany().HasForeignKey(x=>x.EventId).OnDelete(DeleteBehavior.Restrict);
 b.Entity<Enrolment>().HasOne(x=>x.Category).WithMany(x=>x.Enrolments).HasForeignKey(x=>x.CategoryId).OnDelete(DeleteBehavior.Restrict);
 b.Entity<Enrolment>().HasIndex(x=>new{x.ParticipantId,x.EventId}).IsUnique(); b.Entity<RaceResult>().HasIndex(x=>x.EnrolmentId).IsUnique();
 b.Entity<RaceResult>().HasOne(x=>x.Enrolment).WithOne(x=>x.Result).HasForeignKey<RaceResult>(x=>x.EnrolmentId).OnDelete(DeleteBehavior.Cascade);
 }
}
