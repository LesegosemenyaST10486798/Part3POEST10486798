using System.ComponentModel.DataAnnotations;
namespace RaceDay.Api.DTOs;
public record RegisterRequest([Required] string Name,[Required,EmailAddress] string Email,[Required,MinLength(8)] string Password,[Required] string Role);
public record LoginRequest([Required,EmailAddress] string Email,[Required] string Password);
public record ProfileUpdate([Required] string Name);
public record EventRequest([Required] string Name,string Description,DateTime Date,[Required] string Location,decimal DistanceKm,[Required] string EventType);
public record CategoryRequest([Required] string Name);
public record EnrolRequest(int EventId,int CategoryId);
public record ResultRequest(int EnrolmentId,TimeSpan FinishTime,int Position);
