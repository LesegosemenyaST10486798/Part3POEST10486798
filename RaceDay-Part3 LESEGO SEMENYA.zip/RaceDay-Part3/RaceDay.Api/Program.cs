using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Http.Features;

var builder=WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<RaceDb>(o=>o.UseSqlServer(builder.Configuration.GetConnectionString("RaceDay")));
builder.Services.Configure<FormOptions>(o=>o.MultipartBodyLengthLimit=5*1024*1024);
builder.Services.AddScoped<IPasswordHasher<AppUser>,PasswordHasher<AppUser>>();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o=>{
 o.Cookie.Name="RaceDay.Auth"; o.Cookie.HttpOnly=true; o.Cookie.SameSite=SameSiteMode.Lax; o.Cookie.SecurePolicy=CookieSecurePolicy.Always;
 o.Events.OnRedirectToLogin=c=>{c.Response.StatusCode=401;return Task.CompletedTask;};
 o.Events.OnRedirectToAccessDenied=c=>{c.Response.StatusCode=403;return Task.CompletedTask;};
});
builder.Services.AddAuthorization(o=>{o.AddPolicy("OrganiserOnly",p=>p.RequireRole("Organiser"));o.AddPolicy("ParticipantOnly",p=>p.RequireRole("Participant"));});
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(o=>{o.Cookie.HttpOnly=true;o.Cookie.IsEssential=true;o.IdleTimeout=TimeSpan.FromMinutes(30);});
builder.Services.AddEndpointsApiExplorer();builder.Services.AddSwaggerGen();
var app=builder.Build();
app.UseSwagger();app.UseSwaggerUI();if (!app.Environment.IsDevelopment()) app.UseHttpsRedirection();app.UseSession();app.UseAuthentication();app.UseAuthorization();
int uid(ClaimsPrincipal u)=>int.Parse(u.FindFirstValue(ClaimTypes.NameIdentifier)!);
object publicEvent(RaceEvent e)=>new{e.Id,e.Name,e.Description,e.Date,e.Location,e.DistanceKm,e.EventType,e.OrganiserId,HasBanner=e.BannerBlobName!=null};

var auth=app.MapGroup("/api/auth").WithTags("Authentication");
auth.MapPost("/register",async(RegisterRequest r,RaceDb db,IPasswordHasher<AppUser> hasher)=>{
 if(r.Role is not ("Organiser" or "Participant"))return Results.BadRequest("Role must be Organiser or Participant.");
 if(string.IsNullOrWhiteSpace(r.Name)||string.IsNullOrWhiteSpace(r.Email)||r.Password.Length<8)return Results.BadRequest("Name, email and password (8+ characters) are required.");
 var email=r.Email.Trim().ToLowerInvariant();if(await db.Users.AnyAsync(x=>x.Email==email))return Results.Conflict("Email already registered.");
 var user=new AppUser{Name=r.Name.Trim(),Email=email,Role=r.Role};user.PasswordHash=hasher.HashPassword(user,r.Password);
 db.Users.Add(user);await db.SaveChangesAsync();return Results.Created($"/api/profile",new{user.Id,user.Name,user.Email,user.Role});
}).WithSummary("Register a participant or organiser; stores a hashed password");
auth.MapPost("/login",async(LoginRequest r,RaceDb db,IPasswordHasher<AppUser> hasher,HttpContext http)=>{
 var user=await db.Users.SingleOrDefaultAsync(x=>x.Email==r.Email.Trim().ToLowerInvariant());
 if(user is null||hasher.VerifyHashedPassword(user,user.PasswordHash,r.Password)==PasswordVerificationResult.Failed)return Results.Unauthorized();
 var claims=new[]{new Claim(ClaimTypes.NameIdentifier,user.Id.ToString()),new Claim(ClaimTypes.Name,user.Name),new Claim(ClaimTypes.Role,user.Role)};
 await http.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme)));
 http.Session.SetInt32("UserId",user.Id);http.Session.SetString("Role",user.Role);
 return Results.Ok(new{user.Id,user.Name,user.Role});
}).WithSummary("Sign in and establish authenticated cookie and session");
auth.MapPost("/logout",async(HttpContext http)=>{await http.SignOutAsync();http.Session.Clear();return Results.Ok();}).RequireAuthorization().WithSummary("Log out and clear session");

var profile=app.MapGroup("/api/profile").WithTags("Profile").RequireAuthorization();
profile.MapGet("/",async(ClaimsPrincipal u,RaceDb db)=>{var x=await db.Users.FindAsync(uid(u));return x is null?Results.NotFound():Results.Ok(new{x.Id,x.Name,x.Email,x.Role});}).WithSummary("View own profile");
profile.MapPut("/",async(ProfileUpdate r,ClaimsPrincipal u,RaceDb db)=>{var x=await db.Users.FindAsync(uid(u));if(x is null)return Results.NotFound();if(string.IsNullOrWhiteSpace(r.Name))return Results.BadRequest();x.Name=r.Name.Trim();await db.SaveChangesAsync();return Results.Ok(new{x.Id,x.Name,x.Email,x.Role});}).WithSummary("Update own name");

var events=app.MapGroup("/api/events").WithTags("Events");
events.MapGet("/",async(RaceDb db)=>

Results.Ok((await db.Events.AsNoTracking().ToListAsync()).Select(publicEvent))).WithSummary("List all events");
events.MapGet("/mine",async(ClaimsPrincipal u,RaceDb db)=>

{
    var userId = uid(u);

    return Results.Ok((await db.Events.AsNoTracking()
        .Where(x => x.OrganiserId == userId)
        .OrderBy(x => x.Date)
        .ToListAsync())
        .Select(publicEvent));
})
    .RequireAuthorization("OrganiserOnly");
events.MapGet("/{id:int}",async(int id,RaceDb db)=>{var e=await db.Events.FindAsync(id);return e is null?Results.NotFound():Results.Ok(publicEvent(e));}).WithSummary("Get event details");
events.MapPost("/",async(EventRequest r,ClaimsPrincipal u,RaceDb db)=>{
 if(!validEvent(r))return Results.BadRequest("Invalid event fields or type; type must be Run, Walk or Cycle.");
 var e=new RaceEvent{Name=r.Name,Description=r.Description,Date=r.Date,Location=r.Location,DistanceKm=r.DistanceKm,EventType=r.EventType,OrganiserId=uid(u)};
 db.Events.Add(e);await db.SaveChangesAsync();return Results.Created($"/api/events/{e.Id}",publicEvent(e));
}).RequireAuthorization("OrganiserOnly").WithSummary("Organiser creates an event");
events.MapPut("/{id:int}",async(int id,EventRequest r,ClaimsPrincipal u,RaceDb db)=>{
 var e=await db.Events.FindAsync(id);if(e is null)return Results.NotFound();if(e.OrganiserId!=uid(u))return Results.Forbid();if(!validEvent(r))return Results.BadRequest();
 e.Name=r.Name;e.Description=r.Description;e.Date=r.Date;e.Location=r.Location;e.DistanceKm=r.DistanceKm;e.EventType=r.EventType;await db.SaveChangesAsync();return Results.Ok(publicEvent(e));
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser updates an event");
events.MapDelete("/{id:int}",async(int id,ClaimsPrincipal u,RaceDb db)=>{
 var e=await db.Events.FindAsync(id);if(e is null)return Results.NotFound();if(e.OrganiserId!=uid(u))return Results.Forbid();
 if(await db.Enrolments.AnyAsync(x=>x.EventId==id))return Results.Conflict("Cannot delete an event with enrolments.");
 db.Categories.RemoveRange(db.Categories.Where(x=>x.EventId==id));db.Events.Remove(e);await db.SaveChangesAsync();return Results.NoContent();
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser deletes an event without enrolments");

var categories=app.MapGroup("/api/events/{eventId:int}/categories").WithTags("Categories");
categories.MapGet("/",async(int eventId,RaceDb db)=>Results.Ok(await db.Categories.Where(x=>x.EventId==eventId).Select(x=>new{x.Id,x.EventId,x.Name}).ToListAsync())).WithSummary("List categories for an event");
categories.MapPost("/",async(int eventId,CategoryRequest r,ClaimsPrincipal u,RaceDb db)=>{
 var e=await db.Events.FindAsync(eventId);if(e is null)return Results.NotFound();if(e.OrganiserId!=uid(u))return Results.Forbid();if(string.IsNullOrWhiteSpace(r.Name))return Results.BadRequest();
 var c=new EventCategory{EventId=eventId,Name=r.Name};db.Categories.Add(c);await db.SaveChangesAsync();return Results.Created($"/api/events/{eventId}/categories/{c.Id}",new{c.Id,c.EventId,c.Name});
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser adds an age or distance category");
categories.MapPut("/{categoryId:int}",async(int eventId,int categoryId,CategoryRequest r,ClaimsPrincipal u,RaceDb db)=>{
 var c=await db.Categories.Include(x=>x.Event).SingleOrDefaultAsync(x=>x.Id==categoryId&&x.EventId==eventId);if(c is null)return Results.NotFound();if(c.Event.OrganiserId!=uid(u))return Results.Forbid();if(string.IsNullOrWhiteSpace(r.Name))return Results.BadRequest();c.Name=r.Name;await db.SaveChangesAsync();return Results.Ok(new{c.Id,c.Name});
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser updates category");
categories.MapDelete("/{categoryId:int}",async(int eventId,int categoryId,ClaimsPrincipal u,RaceDb db)=>{
 var c=await db.Categories.Include(x=>x.Event).SingleOrDefaultAsync(x=>x.Id==categoryId&&x.EventId==eventId);if(c is null)return Results.NotFound();if(c.Event.OrganiserId!=uid(u))return Results.Forbid();if(await db.Enrolments.AnyAsync(x=>x.CategoryId==categoryId))return Results.Conflict("Category is in use.");db.Categories.Remove(c);await db.SaveChangesAsync();return Results.NoContent();
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser removes unused category");

var enrol=app.MapGroup("/api/enrolments").WithTags("Enrolments");


enrol.MapPost("/",async(EnrolRequest r,ClaimsPrincipal u,RaceDb db)=>{
    var userId = uid(u);

    var category=await db.Categories.FirstOrDefaultAsync(x=>x.Id==r.CategoryId&&x.EventId==r.EventId);if(category is null)return Results.BadRequest("Category must belong to the event.");
 
    if(await db.Enrolments.AnyAsync(x=>
 x.ParticipantId==userId &&
 x.EventId==r.EventId))
        return Results.Conflict("Already enrolled in this event.");

 var item=new Enrolment{ParticipantId=uid(u),EventId=r.EventId,CategoryId=r.CategoryId};db.Enrolments.Add(item);await db.SaveChangesAsync();return Results.Created($"/api/enrolments/mine",new{item.Id,item.EventId,item.CategoryId,item.ParticipantId});
}).RequireAuthorization("ParticipantOnly").WithSummary("Participant enrols in an event category");
enrol.MapGet("/mine",async(ClaimsPrincipal u,RaceDb db)=>
{
    var userId = uid(u);

    return Results.Ok(await db.Enrolments
    .Where(x => x.ParticipantId == userId)
    .Select(x => new
    {
        x.Id,
        x.EventId,
        x.CategoryId,
        x.RegisteredAt,
        x.Status,
        EventName = x.Event.Name,
        EventDate = x.Event.Date,
        CategoryName = x.Category.Name
    })
    .ToListAsync());
    })
    .RequireAuthorization("ParticipantOnly")
    .WithSummary("Participant sees own enrolments");
enrol.MapGet("/event/{eventId:int}",async(int eventId,ClaimsPrincipal u,RaceDb db)=>{
 var e=await db.Events.FindAsync(eventId);if(e is null)return Results.NotFound();if(e.OrganiserId!=uid(u))return Results.Forbid();
 return Results.Ok(await db.Enrolments.Where(x=>x.EventId==eventId).Select(x=>new{x.Id,x.ParticipantId,x.CategoryId,x.RegisteredAt,x.Status,ParticipantName=x.Participant.Name,ParticipantEmail=x.Participant.Email,CategoryName=x.Category.Name}).ToListAsync());
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser views event enrolments");

var results=app.MapGroup("/api/results").WithTags("Results");
results.MapPost("/",async(ResultRequest r,ClaimsPrincipal u,RaceDb db)=>{
 var enrolment=await db.Enrolments.Include(x=>x.Event).SingleOrDefaultAsync(x=>x.Id==r.EnrolmentId);if(enrolment is null)return Results.NotFound();if(enrolment.Event.OrganiserId!=uid(u))return Results.Forbid();if(enrolment.Event.Date>DateTime.Now)return Results.BadRequest("Results can only be published after the event date and time.");if(r.Position<1||r.FinishTime<=TimeSpan.Zero)return Results.BadRequest();
 
    var result=await db.Results.SingleOrDefaultAsync(x=>x.EnrolmentId==r.EnrolmentId);if(result is null)
    {
        result=new RaceResult{EnrolmentId=r.EnrolmentId};db.Results.Add(result);
    }
    result.Position=r.Position;result.FinishTime=r.FinishTime;await db.SaveChangesAsync();
    return Results.Ok(new{result.Id,result.EnrolmentId,result.Position,result.FinishTime});
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser records or updates finish time and position");
results.MapGet("/",async(ClaimsPrincipal u,RaceDb db)=>

{
    var userId = uid(u);

return Results.Ok(await db.Results
    .Where(x => x.Enrolment.ParticipantId == userId)
    .Select(x => new
    {
        x.Id,
        x.EnrolmentId,
        x.Enrolment.EventId,
        x.FinishTime,
        x.Position, EventName = x.
        Enrolment.Event.Name, EventDate = x.
        Enrolment.Event.Date, CategoryName = x.
        Enrolment.Category.Name, TotalFinishers = db.Results.Count(r => r.Enrolment.EventId == x.Enrolment.EventId) })
    .ToListAsync());
})
    .RequireAuthorization("ParticipantOnly").WithSummary("Participant views own results");
results.MapGet("/event/{eventId:int}",async(int eventId,ClaimsPrincipal u,RaceDb db)=>{
 var e=await db.Events.FindAsync(eventId);if(e is null)return Results.NotFound();if(e.OrganiserId!=uid(u))return Results.Forbid();return Results.Ok(await db.Results.Where(x=>x.Enrolment.EventId==eventId).Select(x=>new{x.Id,x.EnrolmentId,x.FinishTime,x.Position,ParticipantName=x.Enrolment.Participant.Name}).ToListAsync());
}).RequireAuthorization("OrganiserOnly").WithSummary("Owner organiser views event results");

// File operations remain in the API. MVC only forwards multipart requests or reads images.
// Objects are stored in a private Azure Blob container (Azurite locally).
async Task<BlobContainerClient?> ImageContainer(IConfiguration cfg) {
 var connection=cfg["AzureStorage:ConnectionString"];
 if (string.IsNullOrWhiteSpace(connection)) return null;
 try {
  var container=new BlobContainerClient(connection,"raceday-images");
  await container.CreateIfNotExistsAsync(PublicAccessType.None);
  return container;
 } catch(Azure.RequestFailedException){return null;}
 catch(HttpRequestException){return null;}
 catch(TaskCanceledException){return null;}
}
static bool AllowedImage(IFormFile f) => f.Length>0 && f.Length<=5*1024*1024 &&
 (f.ContentType=="image/jpeg"||f.ContentType=="image/png"||f.ContentType=="image/webp");
static async Task<bool> ValidImageSignature(IFormFile file) {
 var head=new byte[12]; using var stream=file.OpenReadStream();
 var read=await stream.ReadAsync(head);
 return (file.ContentType=="image/jpeg" && read>=3 && head[0]==0xff && head[1]==0xd8 && head[2]==0xff)
     || (file.ContentType=="image/png" && read>=8 && head.AsSpan(0,8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10}))
     || (file.ContentType=="image/webp" && read>=12 && System.Text.Encoding.ASCII.GetString(head,0,4)=="RIFF" && System.Text.Encoding.ASCII.GetString(head,8,4)=="WEBP");
}
static bool TrustedMvcUpload(HttpRequest request) => request.Headers["X-RaceDay-Mvc"]=="1";
async Task<IResult> UploadBanner(int eventId,HttpContext http,RaceDb db,IConfiguration cfg) {
 if(!TrustedMvcUpload(http.Request)) return Results.Forbid();
 var e=await db.Events.FindAsync(eventId);
 if(e is null) return Results.NotFound();
 if(e.OrganiserId!=uid(http.User)) return Results.Forbid();
 if(!http.Request.HasFormContentType) return Results.BadRequest("An image must be submitted.");
 var file=(await http.Request.ReadFormAsync()).Files.GetFile("file");
 if(file is null||!AllowedImage(file)||!await ValidImageSignature(file))return Results.BadRequest("Upload a JPG, PNG or WEBP up to 5MB.");
 var container=await ImageContainer(cfg); if(container is null)return Results.Problem("Storage is not configured.",statusCode:503);
 var blobName=$"events/{eventId}/{Guid.NewGuid():N}";
 var blob=container.GetBlobClient(blobName);
 await using(var input=file.OpenReadStream())await blob.UploadAsync(input,new BlobUploadOptions{HttpHeaders=new BlobHttpHeaders{ContentType=file.ContentType}});
 var old=e.BannerBlobName;e.BannerBlobName=blobName;await db.SaveChangesAsync();
 if(old is not null)await container.DeleteBlobIfExistsAsync(old);
 return Results.Ok(new{HasBanner=true});
}
events.MapPost("/{eventId:int}/banner",UploadBanner).RequireAuthorization("OrganiserOnly");
events.MapGet("/{eventId:int}/banner",async(int eventId,RaceDb db,IConfiguration cfg)=>{
 var e=await db.Events.FindAsync(eventId);if(e?.BannerBlobName is null)return Results.NotFound();
 var container=await ImageContainer(cfg);if(container is null)return Results.NotFound();
 var blob=container.GetBlobClient(e.BannerBlobName);if(!await blob.ExistsAsync())return Results.NotFound();
 var data=await blob.DownloadContentAsync();
 return Results.File(data.Value.Content.ToArray(),data.Value.Details.ContentType??"image/jpeg");
});
profile.MapPost("/photo",async(HttpContext http,RaceDb db,IConfiguration cfg)=>{
 if(!TrustedMvcUpload(http.Request))return Results.Forbid();
 if(!http.Request.HasFormContentType)return Results.BadRequest();
 var file=(await http.Request.ReadFormAsync()).Files.GetFile("file");
 if(file is null||!AllowedImage(file)||!await ValidImageSignature(file))return Results.BadRequest("Upload a JPG, PNG or WEBP up to 5MB.");
 var container=await ImageContainer(cfg);if(container is null)return Results.Problem("Storage is not configured.",statusCode:503);
 var user=await db.Users.FindAsync(uid(http.User));if(user is null)return Results.NotFound();
 var blobName=$"profiles/{user.Id}/{Guid.NewGuid():N}";
 await using(var input=file.OpenReadStream()) await container.GetBlobClient(blobName).UploadAsync(input,new BlobUploadOptions{HttpHeaders=new BlobHttpHeaders{ContentType=file.ContentType}});
 var old=user.ProfileBlobName;user.ProfileBlobName=blobName;await db.SaveChangesAsync();
 if(old is not null)await container.DeleteBlobIfExistsAsync(old);
 return Results.Ok();
});
profile.MapGet("/photo",async(ClaimsPrincipal u,RaceDb db,IConfiguration cfg)=>{
 var user=await db.Users.FindAsync(uid(u));if(user?.ProfileBlobName is null)return Results.NotFound();
 var container=await ImageContainer(cfg);if(container is null)return Results.NotFound();
 var blob=container.GetBlobClient(user.ProfileBlobName);if(!await blob.ExistsAsync())return Results.NotFound();
 var data=await blob.DownloadContentAsync();return Results.File(data.Value.Content.ToArray(),data.Value.Details.ContentType??"image/jpeg");
});
// Automatic schema creation is only intended for a fresh local Docker demo database.
if(builder.Configuration.GetValue<bool>("RaceDay:CreateDatabaseOnStart")) {
 using var scope=app.Services.CreateScope();var db=scope.ServiceProvider.GetRequiredService<RaceDb>();
 for(var attempt=0;attempt<30;attempt++){
  try{await db.Database.EnsureCreatedAsync();break;}
  catch(Exception) when(attempt<29){await Task.Delay(2000);}
 }
}

app.Run();
static bool validEvent(EventRequest r)=>!string.IsNullOrWhiteSpace(r.Name)&&!string.IsNullOrWhiteSpace(r.Location)&&r.DistanceKm>0&&r.Date!=default&&r.EventType is "Run" or "Walk" or "Cycle";
public partial class Program {}
