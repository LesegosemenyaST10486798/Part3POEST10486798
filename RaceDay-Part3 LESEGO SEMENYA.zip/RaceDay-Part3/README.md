# RaceDay — Part 3 ASP.NET Core MVC + Part 2 REST API

A race-event platform for **Organisers** and **Participants**. The MVC web app **only consumes the Part 2 API**: it never opens SQL Server or uses Entity Framework. The API owns all data operations and Azure Blob Storage file operations.

> **Original project provenance:** The API and test files were reconstructed from the earlier `RaceDay-Part2-Source-Code.md` project. That Part 2 design was provisional because the approved Part 1 ERD was not supplied. Check alignment with your actual submitted Part 2 before replacing it.

## Features

- **Shared:** register, sign in, sign out, session + role-aware navigation, update profile, upload profile photo.
- **Organiser:** dashboard with owned events/enrolment totals, create/edit/delete event, upload banner, add/edit/delete categories, view participants/statuses, record positions and finish times.
- **Participant:** browse and filter upcoming events, view details/categories, enrol in category, view own enrolments and status, view history with finish times and positions.
- **Cloud files:** the API uploads and streams images from a **private Azure Blob container** (`raceday-images`); the MVC never calls Azure directly. Local Docker uses Azurite, an Azure Storage emulator. Point the API to a real Azure Storage account for live cloud use.
- **Containerisation:** separate multi-stage Docker images for MVC and API, non-root runtime user, SQL Server and Azurite in `compose.yaml`.

## Quick start — recommended (one command)

1. Install Docker Desktop, switch to **Linux containers**, enable WSL2 if prompted, and make sure Docker Engine is running. SQL Server uses a substantial amount of memory; allocate about 4 GB or more.
2. Open PowerShell or terminal in the **`RaceDay-Part3`** folder.
3. Run:

```powershell
docker compose up --build
```

4. Browse **http://localhost:5088** (MVC). The API Swagger is at **http://localhost:5044/swagger**.
5. Register one Organiser and one Participant (different emails) and test the full enrolment/result workflow.
6. Stop: Ctrl+C; remove containers with `docker compose down`. To **wipe demo data**, run `docker compose down -v` (irreversible).

For first-time setup, copy `.env.example` to `.env` and change `MSSQL_SA_PASSWORD`. These are local demo values, **not production credentials**.

### Required single `docker run` command for the MVC application

**Start the API first** (e.g. via `docker compose up -d api sql azurite`, or an independently running compatible Part 2 API). Then, after building the MVC image from the repository root:

```powershell
docker build -f RaceDay.Mvc/Dockerfile -t raceday-mvc .
```

```powershell
docker run --rm -p 5088:8080 --add-host=host.docker.internal:host-gateway -e Api__BaseUrl=http://host.docker.internal:5044/ raceday-mvc
```

In PowerShell on Windows, `host.docker.internal` resolves to the host. The API must be reachable at port 5044, and the API itself must have a database and storage configured. `docker run` starts the MVC app with **one command** once its image and the dependent API exist. Alternatively, `docker compose up --build` brings up the **entire** stack with one command.

## Run locally without Docker

Prerequisites: .NET 8 SDK, SQL Server LocalDB/SQL Server instance, Azure Storage account **or** Azurite.

1. Set the API SQL connection string in `RaceDay.Api/appsettings.json` or with user secrets/environment variables. Set `AzureStorage__ConnectionString` (locally, `UseDevelopmentStorage=true` if Azurite is running on default ports).
2. For a **fresh demo database only**, set `RaceDay__CreateDatabaseOnStart=true` on the API. For an existing Part 2 database, use **EF Core migrations** to add the new `ProfileBlobName`, `BannerBlobName`, and `Status` columns. Do **not** call `EnsureCreated` on an existing database managed by migrations.
3. Start the API:

   ```powershell
   dotnet run --project RaceDay.Api --launch-profile https
   ```

   The supplied launch profile listens on `https://localhost:7044` and `http://localhost:5044`. To use HTTPS for MVC→API communication, change `RaceDay.Mvc/appsettings.json` `Api:BaseUrl` to `https://localhost:7044/`.
4. Start the MVC separately:

   ```powershell
   dotnet run --project RaceDay.Mvc --launch-profile http
   ```

5. Browse `http://localhost:5088`.

### Data model and Part 2 alignment

The API contains Users, Events, Categories, Enrolments, Results with new fields for Blob filenames and enrolment status. All business validation / ownership checks remain in the API. The web app has **view models and DTOs only, not database entities or DbContext**. The original SQL migration history is not included in the prior source; do not assume it matches a pre-existing local database.

### File upload flow

Organiser/Participant selects image in MVC → browser POST + anti-forgery token to MVC → MVC forwards multipart file & authenticated API cookie → API validates type, size & header signature → private blob container → blob filename in SQL → API streams image on request → MVC displays image. **No Azure access from MVC.**

### MVC authentication flow

Login form → API `POST /api/auth/login` → API sets signed-in cookie → MVC stores that API cookie in its server-side session and creates MVC cookie authentication claims → subsequent MVC requests forward the API cookie to the API. MVC controllers use `[Authorize(Roles="Organiser")]` and `[Authorize(Roles="Participant")]`. Protected POSTs carry MVC anti-forgery tokens; API authorises every action too. For a production deployment use distributed session storage (e.g. Redis), persisted Data Protection keys and TLS.

### Important safeguards

- Private Azure Blob container, never exposes Azure secrets to MVC or browser.
- Check MIME type, size 5 MB max, and file signatures; public event banner served through API proxy.
- Validated form inputs; friendly errors for API failures.
- SQL credentials from local environment, not committed; no actual production secrets included.
- API has a compatibility `CreateDatabaseOnStart` toggle for **fresh local demo only**. Plan proper EF migrations and hardened HTTPS, cookie/session persistence before live deployment.
- Self-service Organiser registration is an assignment choice, **not recommended for a real production business**.
- **Time-sensitive:** The original source uses .NET 8, which reaches end of support on **10 November 2026**. To deploy beyond coursework, upgrade the API, MVC, CI and Docker images to .NET 10 LTS together.

## Tests and CI

```powershell
dotnet build RaceDay.Mvc/RaceDay.Mvc.csproj
dotnet build RaceDay.Api/RaceDay.Api.csproj
dotnet test RaceDay.Tests/RaceDay.Tests.csproj
```

`.github/workflows/ci.yml` restores/builds **both** projects, runs API integration tests and builds the MVC Docker image on every push/PR. Test the Docker stack yourself and capture a **real successful GitHub Actions screenshot** for the submission evidence.

## GitHub submission

1. Keep the original Part 2 code/commits in your existing GitHub repository. Put this in a clearly named `Part3` subfolder or branch, depending on your lecturer's instructions.
2. Make **20 or more genuine, meaningful commits** while implementing and testing your work (they cannot be fabricated by a ZIP).
3. Submit your actual GitHub repository URL on ARC.
4. Record a **real unlisted YouTube demo**: show login for both roles, organiser dashboard, event CRUD, banner upload/Blob Storage, categories, participant enrolments/results, project MVC structure, Docker container/Compose and successful GitHub Actions.
5. Put your video link here before submission: **[PASTE YOUR UNLISTED YOUTUBE URL]**.

See [`docs/SUBMISSION_CHECKLIST.md`](docs/SUBMISSION_CHECKLIST.md) and [`docs/FOLDER_STRUCTURE.md`](docs/FOLDER_STRUCTURE.md).

## Disclaimer on verification

This package was assembled without .NET SDK or Docker Engine in the creation environment, so compilation, integration tests and container startup have **not** been executed here. Run all commands on your own machine and resolve any environment-specific failures. Do not submit it as a verified working production build before testing.

## Existing GitHub repository hand-off

An existing RaceDay Part 2 repository was identified. See [`docs/GITHUB_UPLOAD.md`](docs/GITHUB_UPLOAD.md) for the repository link, important note about missing root-level API source, and safe branch/subfolder workflow. **GitHub Actions only discovers workflows at the repository root**; if you copy this package into a nested `RaceDay-Part3` folder, move the CI workflow to the repository root and update its paths.
