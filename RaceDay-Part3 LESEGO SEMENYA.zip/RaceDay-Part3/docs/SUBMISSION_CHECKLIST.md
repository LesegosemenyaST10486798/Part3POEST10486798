# RaceDay Part 3 — Submission checklist (100 marks)

## 1. MVC application setup
- [ ] MVC app consumes Part 2 API for every data operation.
- [ ] No DbContext, SQL connection string or duplicated server business logic in MVC.

## 2. Authentication and navigation
- [ ] Register as Organiser and Participant, sign in, sign out.
- [ ] Demonstrate protected pages redirect logged-out users to login.
- [ ] Organiser/Participant role-specific navigation and blocked unauthorised access.

## 3. Organiser interface
- [ ] Dashboard lists only organiser-created events; counts and dates show.
- [ ] Create/edit/delete event with name, description, date, location, distance, type.
- [ ] Upload banner and see image in event detail page.
- [ ] Create/edit/delete event categories (e.g. 5km, 10km, Under 18).
- [ ] View enrolled participant names, categories, and status.
- [ ] Record and publish finish time & finishing position.

## 4. Participant interface
- [ ] Filter/search upcoming events.
- [ ] View event details and categories.
- [ ] Enrol; immediate confirmation visible in My Enrolments.
- [ ] My Enrolments and colour-coded statuses.
- [ ] My Results shows event, date, category, recorded finish time and rank/out of finishers.
- [ ] Profile update and Azure Blob profile picture.

## 5. Azure Blob Storage
- [ ] API has real Azure Blob integration; MVC never touches Azure directly.
- [ ] Photo/banner upload, private storage, and display work.
- [ ] Demo with real Azure Storage or explain Azurite is only a local emulator.

## 6. Docker
- [ ] `docker compose up --build` launches entire stack.
- [ ] MVC `docker run` command shown in README and tested.
- [ ] Demonstrate MVC locally and in container with same UX/data via same API.

## 7. UI
- [ ] Consistent branding, responsive navigation and forms.
- [ ] Friendly validation feedback (no raw stack traces).

## 8. GitHub / CI
- [ ] Repo includes code, Dockerfiles, README, video URL.
- [ ] Part 3 clearly named folder/branch; at least 20 genuine commits.
- [ ] GitHub Actions passes with API and MVC builds.
- [ ] Add authentic screenshot to docs/ci-success.png.

## Submission
- [ ] GitHub link submitted on ARC.
- [ ] Unlisted YouTube demonstrates full app, MVC structure, Blob Storage and Docker.
- [ ] [PASTE REAL REPOSITORY URL]
- [ ] [PASTE UNLISTED VIDEO URL]
