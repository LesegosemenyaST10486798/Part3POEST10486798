# Put this Part 3 into your existing GitHub repository

The connected repository checked on **9 November 2026** is:

`https://github.com/LesegosemenyaST10486798/2026Part2POEST10486798`

Its default-branch root currently contains `README.md` and `.github/`. The source files for the Part 2 API are **not** currently visible in the root. The README lists 20+ work steps and the repository has 23 recorded commits, but commit count alone does not demonstrate functional API source code.

## Safe upload plan

1. Open the existing repository in Visual Studio/GitHub Desktop, or clone it using the following command:

   ```powershell
   git clone https://github.com/LesegosemenyaST10486798/2026Part2POEST10486798.git
   cd 2026Part2POEST10486798
   ```

2. Create a clearly named new branch to preserve your Part 2 work:

   ```powershell
   git switch -c part3-mvc-docker
   ```

3. Extract the submitted ZIP and **copy the inner `RaceDay-Part3/` folder** into the repository as a subfolder. The structure should be `2026Part2POEST10486798/RaceDay-Part3/RaceDay.sln`.

4. Test locally first; run `docker compose up --build` **from inside the `RaceDay-Part3` directory**.

5. Commit your source only after it is tested. Example:

   ```powershell
   git add RaceDay-Part3
   git commit -m "Add Part 3 MVC front end and API image support"
   git push -u origin part3-mvc-docker
   ```

6. For coursework marking, your history should reflect **20 or more authentic, meaningful improvements** to the project. The number of commits on the old branch does not automatically certify quality. Do not manufacture commit history to meet an assessment requirement.

7. Make sure GitHub Actions runs on the new branch. Since CI workflow lives inside `RaceDay-Part3/.github/workflows/ci.yml`, **GitHub Actions will not discover it in a nested folder**. Copy the workflow to the **repository root** at `.github/workflows/ci.yml`, and change all workflow project paths to be prefixed with `RaceDay-Part3/`, for example `dotnet build RaceDay-Part3/RaceDay.Mvc/RaceDay.Mvc.csproj`. Change Docker context to `RaceDay-Part3` and Dockerfile path to `RaceDay-Part3/RaceDay.Mvc/Dockerfile`.

8. Record the live application and paste your **actual unlisted YouTube URL** in the README before submission.

## Avoid overwriting your actual Part 2 implementation

The API included in this ZIP comes from the previously prepared **provisional Part 2 source document**. If you have since changed your Part 2 database, routes, or models, merge the MVC into your real API carefully; do not replace your tested API blindly.
