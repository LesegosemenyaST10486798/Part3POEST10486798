# Where each file belongs

```
RaceDay-Part3/
├── RaceDay.Api/                  # Part 2 API + Azure image endpoints (SQL and Blob here ONLY)
│   ├── Data/RaceDb.cs
│   ├── DTOs/Requests.cs
│   ├── Models/Entities.cs
│   ├── Program.cs
│   ├── RaceDay.Api.csproj
│   ├── appsettings.json
│   └── Dockerfile
├── RaceDay.Mvc/                  # Part 3 ASP.NET Core MVC web frontend
│   ├── Controllers/
│   │   ├── AccountController.cs
│   │   ├── HomeController.cs
│   │   ├── OrganiserController.cs
│   │   ├── ParticipantController.cs
│   │   └── MediaController.cs
│   ├── Models/ApiModels.cs       # form/view models, NO database!
│   ├── Services/RaceDayApiClient.cs  # only API client
│   ├── Views/
│   │   ├── Shared/              # branded layout, event card
│   │   ├── Account/             # register, login, profile
│   │   ├── Home/                # event listing and details
│   │   ├── Organiser/           # dashboard, event/category management
│   │   └── Participant/         # dashboard, enrolments, race results
│   ├── wwwroot/css/site.css     # all visual styling
│   ├── Program.cs
│   ├── appsettings.json
│   ├── RaceDay.Mvc.csproj
│   └── Dockerfile
├── RaceDay.Tests/                # original API xUnit tests
├── .github/workflows/ci.yml    # CI builds API, MVC and Docker
├── compose.yaml                 # MVC + API + SQL + Azurite
├── .dockerignore
├── .env.example
├── .gitignore
├── README.md
└── docs/
    ├── FOLDER_STRUCTURE.md
    └── SUBMISSION_CHECKLIST.md
```

For a Visual Studio solution, open the repo folder in Visual Studio 2022 or run:

```powershell
dotnet new sln -n RaceDay
dotnet sln RaceDay.sln add RaceDay.Api/RaceDay.Api.csproj RaceDay.Mvc/RaceDay.Mvc.csproj RaceDay.Tests/RaceDay.Tests.csproj
```
